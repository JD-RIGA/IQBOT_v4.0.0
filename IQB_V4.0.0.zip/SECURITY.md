# Seguridad

- No publiques credenciales ni sesiones dentro del repositorio.
- `data/` está ignorado por defecto (ver `.gitignore`).
- Reporta vulnerabilidades abriendo un issue con detalles mínimos y forma de reproducir.
