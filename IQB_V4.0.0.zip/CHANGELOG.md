# Changelog

## 2025-08-25
- Estructura limpia para GitHub.
- `README.md` renovado.
- `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`, `LICENSE`, `.gitignore`, `SECURITY.md`.
- `data/config.example.json` y exclusión de datos locales.
