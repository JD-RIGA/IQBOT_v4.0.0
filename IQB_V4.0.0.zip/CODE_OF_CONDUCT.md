# Código de Conducta

Este proyecto adopta el [Contributor Covenant](https://www.contributor-covenant.org/).  
Esperamos interacciones respetuosas y colaborativas.

Para reportar incidentes, abre un issue o contacta a los mantenedores.
