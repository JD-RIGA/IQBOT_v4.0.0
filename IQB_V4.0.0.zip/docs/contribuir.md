# Guía para contribuir

- Usa ramas por feature: `feat/ui-scroll`, `fix/recovery-edge`.
- Commits descriptivos: `feat(panel): agregar toggle demo/real`.
- Tests manuales: conexión, clics, alternancia, logs, recuperación.
- Revisa `solucion_problemas.md` antes de abrir issues.
