# Plantilla de CHANGELOG

## [x.y.z] - YYYY-MM-DD
### Added
- 

### Changed
- 

### Fixed
- 

### Removed
- 
